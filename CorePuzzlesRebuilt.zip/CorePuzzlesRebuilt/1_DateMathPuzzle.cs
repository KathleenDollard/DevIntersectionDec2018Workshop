﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CorePuzzles
{
    [TestClass]
    public class DateMathPuzzle
    {
        [TestMethod]
        public void TestMethod1()
        {
            // See Context
        }
    }
}
